const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** تبدیل تمام ارقام لاتین یک رشته یا عدد به ارقام فارسی */
export function fa(value: string | number): string {
  return String(value).replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}

/** قالب‌بندی عدد با جداکنندهٔ هزارگان فارسی (٬) و ارقام فارسی */
export function faNumber(value: number): string {
  return fa(value.toLocaleString("en-US").replace(/,/g, "٬"));
}
