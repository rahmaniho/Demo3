import { fa } from "./fa";

export type Work = {
  id: string;
  num: string;
  title: string;
  accent: string;
  meta: string;
  category: string;
  year: string;
  src: string;
  aspect: string;
  span: string;
  row: string;
};

const px = (id: number, w: number, h: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

export const IMG = {
  ines: px(7630665, 900, 1100),
  hayden: px(23879313, 800, 1000),
  roe: px(19615558, 1400, 950),
  light: px(30552590, 800, 1000),
  lior: px(13422346, 800, 1050),
  astor: px(36103802, 800, 1050),
  mara: px(30734121, 800, 1050),
  studio: px(7383644, 1800, 1100),
  saoirse: px(13921897, 900, 1150),
  keljune: px(5962786, 900, 1100),
  hands: px(30552600, 900, 900),
  eowyn: px(39166890, 900, 900),
  cassia: px(14242446, 900, 900),
  noor: px(36506157, 900, 900),
  studioLate: px(12616007, 1800, 1000),
  /* landscape tier images */
  tierSitting: px(1443388, 1000, 560),
  tierEditorial: px(11003631, 1000, 560),
  tierCampaign: px(19437732, 1000, 560),
  studioAlt: px(30332804, 1200, 800),
};

export const STUDIO = {
  latin: "noir.",
  persian: "نوآر",
  photographer: "مارن اوکادا",
  city: "بروکلین، نیویورک",
  email: "studio@noir.work",
  phone: "+1 (347) 555 0142",
  phoneFa: "+۱ (۳۴۷) ۵۵۵ ۰۱۴۲",
  tagline: "کارگاهی کوچک برای پرتره در بروکلین. تحریریه، برند و جلسه‌های خصوصی — روی فیلم، چاپ با دست.",
};

export const NAV = [
  { label: "کارها", href: "#features" },
  { label: "نمونه‌کارها", href: "#/portfolio" },
  { label: "نرخ‌نامه", href: "#pricing" },
  { label: "استودیو", href: "#about" },
];

export const SESSIONS = [
  {
    n: `۰۱ / تحریریه`,
    icon: "camera",
    title: "پرتره‌های تحریریه.",
    desc: "پرتره‌هایی در تراز مجله برای گزارش‌های مطبوعاتی، پرونده‌های شخصی و برندسازی فردی. آرام، سنجیده و هرگز شتاب‌زده.",
  },
  {
    n: `۰۲ / استودیو`,
    icon: "flash",
    title: "جلسه‌های کنترل‌شده در استودیو.",
    desc: "شکل‌دهی نور سینمایی در استودیویی ۲۲۰ متری در بروکلین. همراهی کامل در پوشاک و پیش‌نمایش ویرایش در محل.",
  },
  {
    n: `۰۳ / چهره‌نگار`,
    icon: "user",
    title: "چهره‌نگاره‌هایی که زنده‌اند.",
    desc: "نه آن چهره‌نگاره‌های فلورسنتیِ لینکدین. پرتره‌هایی سنجیده که شبیه یک انسان‌اند، نه قالب سازمانی.",
  },
  {
    n: `۰۴ / زوج‌ها`,
    icon: "heart",
    title: "زوج‌ها و لحظه‌های صمیمی.",
    desc: "جلسه‌های دوتایی که بیش از یک عکاسی، شبیه شبی دل‌نشین است که کسی آن را ثبت کرده باشد.",
  },
  {
    n: `۰۵ / برند`,
    icon: "store",
    title: "کمپین‌های برند.",
    desc: "پرترهٔ بنیان‌گذاران، لوک‌بوک‌ها و هویت بصری برای استودیوهایی که می‌خواهند عکاسی بوی کارگردانی هنری بدهد.",
  },
  {
    n: `۰۶ / آنالوگ`,
    icon: "film",
    title: "فیلم، به انتخابی آگاهانه.",
    desc: "فرمت متوسط هاسلبلاد و لایکای ۳۵ میلی‌متری. دانه‌ها فیلتر نیستند؛ خودِ نقره‌اند.",
  },
];

export const WORK: Work[] = [
  {
    id: "a1",
    num: "۰۱",
    title: "اینِس",
    accent: "دورهٔ ۱۴",
    meta: "تحریریه — برای مجلهٔ آبجکت",
    category: "تحریریه",
    year: "۲۰۲۶",
    src: IMG.ines,
    aspect: "aspect-[4/5]",
    span: "md:col-span-7",
    row: "a",
  },
  {
    id: "a2",
    num: "۰۲",
    title: "هیدن",
    accent: "کمپین",
    meta: "برند · لوک‌بوک برای استودیوهای مارا",
    category: "برند",
    year: "۲۰۲۵",
    src: IMG.hayden,
    aspect: "aspect-[4/5]",
    span: "md:col-span-5",
    row: "a",
  },
  {
    id: "b1",
    num: "۰۳",
    title: "رو",
    accent: "جلسهٔ ۰۲",
    meta: "تحریریه · گزارش برای «یادداشت‌های میدانی»",
    category: "تحریریه",
    year: "۲۰۲۶",
    src: IMG.roe,
    aspect: "aspect-[4/3]",
    span: "md:col-span-8",
    row: "b",
  },
  {
    id: "b2",
    num: "۰۴",
    title: "مطالعهٔ نور",
    accent: "شمارهٔ ۳",
    meta: "شخصی — مجموعهٔ فیلم",
    category: "شخصی",
    year: "۲۰۲۵",
    src: IMG.light,
    aspect: "aspect-[3/4]",
    span: "md:col-span-4",
    row: "b",
  },
  {
    id: "c1",
    num: "۰۵",
    title: "لیور",
    accent: "دورهٔ ۰۹",
    meta: "تحریریه · موسیقی — «رکوردز آرام»",
    category: "تحریریه",
    year: "۲۰۲۵",
    src: IMG.lior,
    aspect: "aspect-[3/4]",
    span: "md:col-span-4",
    row: "c",
  },
  {
    id: "c2",
    num: "۰۶",
    title: "آستور",
    accent: "دونفره",
    meta: "خصوصی · زوج‌ها",
    category: "زوج‌ها",
    year: "۲۰۲۵",
    src: IMG.astor,
    aspect: "aspect-[3/4]",
    span: "md:col-span-4",
    row: "c",
  },
  {
    id: "c3",
    num: "۰۷",
    title: "مارا",
    accent: "بنیان‌گذار",
    meta: "برند · مطبوعات برای استودیوهای مارا",
    category: "برند",
    year: "۲۰۲۶",
    src: IMG.mara,
    aspect: "aspect-[3/4]",
    span: "md:col-span-4",
    row: "c",
  },
  {
    id: "d1",
    num: "۰۸",
    title: "استودیو",
    accent: "شمارهٔ ۱۴",
    meta: "پشت‌صحنه — فضای بروکلین",
    category: "استودیو",
    year: "۲۰۲۶",
    src: IMG.studio,
    aspect: "aspect-[16/10]",
    span: "md:col-span-12",
    row: "d",
  },
  {
    id: "e1",
    num: "۰۹",
    title: "سِرشا",
    accent: "جلد",
    meta: "تحریریه · جلد «فصل‌نامهٔ آرام»",
    category: "تحریریه",
    year: "۲۰۲۴",
    src: IMG.saoirse,
    aspect: "aspect-[4/5]",
    span: "md:col-span-6",
    row: "e",
  },
  {
    id: "e2",
    num: "۱۰",
    title: "کل و جون",
    accent: "جفت",
    meta: "خصوصی · زوج‌ها — جلسهٔ سالگرد",
    category: "زوج‌ها",
    year: "۲۰۲۴",
    src: IMG.keljune,
    aspect: "aspect-[4/5]",
    span: "md:col-span-6",
    row: "e",
  },
  {
    id: "f1",
    num: "۱۱",
    title: "دست‌ها",
    accent: "مطالعهٔ ۰۲",
    meta: "شخصی — مجموعهٔ جزئیات",
    category: "شخصی",
    year: "۲۰۲۴",
    src: IMG.hands,
    aspect: "aspect-square",
    span: "md:col-span-3",
    row: "f",
  },
  {
    id: "f2",
    num: "۱۲",
    title: "اِووین",
    accent: "آنالوگ",
    meta: "شخصی — فیلم",
    category: "شخصی",
    year: "۲۰۲۴",
    src: IMG.eowyn,
    aspect: "aspect-square",
    span: "md:col-span-3",
    row: "f",
  },
  {
    id: "f3",
    num: "۱۳",
    title: "کاسیا",
    accent: "نیمرخ",
    meta: "تحریریه · مطبوعات",
    category: "تحریریه",
    year: "۲۰۲۵",
    src: IMG.cassia,
    aspect: "aspect-square",
    span: "md:col-span-3",
    row: "f",
  },
  {
    id: "f4",
    num: "۱۴",
    title: "نور",
    accent: "کمپین",
    meta: "برند · لوک‌بوک",
    category: "برند",
    year: "۲۰۲۵",
    src: IMG.noor,
    aspect: "aspect-square",
    span: "md:col-span-3",
    row: "f",
  },
  {
    id: "g1",
    num: "۱۵",
    title: "استودیو، آخرِ بعدازظهر",
    accent: "شمارهٔ ۲۱",
    meta: "پشت‌صحنه — گوشهٔ نور طبیعی",
    category: "استودیو",
    year: "۲۰۲۶",
    src: IMG.studioLate,
    aspect: "aspect-[16/9]",
    span: "md:col-span-12",
    row: "g",
  },
];

export const PREVIEW = WORK.slice(0, 4);

export const CATEGORIES = ["همه", "تحریریه", "برند", "زوج‌ها", "شخصی", "استودیو"];

export const TIERS = [
  {
    name: "جلسه",
    tag: "۰۱ / استودیو",
    description: "جلسهٔ پرترهٔ متمرکز و تک‌موضوع در استودیوی بروکلین.",
    half: 1200,
    full: 2000,
    image: IMG.tierSitting,
    features: [
      "۱ سوژه، ۱ لوکیشن",
      "۳ تغییر پوشاک",
      "تا ۳۰ قاب ریتوش‌شده",
      "تحویل دیجیتال در ۷ روز",
      "یک چاپ آرشیوی ۱۲×۱۶ اینچ",
    ],
    cta: "رزرو جلسه",
    highlight: false,
  },
  {
    name: "تحریریه",
    tag: "۰۲ / مجله",
    description: "برای گزارش‌های منتشرشده، پرونده‌های مطبوعاتی و روایت‌های برند.",
    half: 3800,
    full: 5400,
    image: IMG.tierEditorial,
    features: [
      "۱ تا ۲ سوژه، چند لوک",
      "استودیو کامل + تهیه‌کنندهٔ در محل",
      "تا ۸۰ قاب ریتوش‌شده",
      "پروفِ فیلم در ۲۴ ساعت، ویرایش کامل در ۷ روز",
      "سه چاپ آرشیوی ۱۲×۱۶ اینچ",
      "مجوز استفادهٔ تحریریه‌ای",
    ],
    cta: "آغاز یک بریف",
    highlight: true,
  },
  {
    name: "کمپین",
    tag: "۰۳ / برند",
    description: "تولید چندروزهٔ برند و لوک‌بوک، از آغاز تا پایان.",
    half: 9000,
    full: 14000,
    image: IMG.tierCampaign,
    features: [
      "چند روز، چند لوک",
      "تیم کامل + کارگردانی هنری",
      "قاب‌های ریتوش‌شدهٔ نامحدود",
      "فیلم پشت‌صحنه",
      "مجوز استفادهٔ جهانی",
      "مسئول تولید اختصاصی",
    ],
    cta: "گفت‌وگو با استودیو",
    highlight: false,
  },
];

export const ADDONS = [
  { code: "+A", name: "آرایش و مو", price: "از ۴۵۰ دلار", desc: "هنرمند در محل، تمام‌روز." },
  { code: "+B", name: "استایلیست و پوشاک", price: "از ۶۸۰ دلار", desc: "تهیه و بازگرداندن لباس‌ها در قیمت لحاظ شده." },
  { code: "+C", name: "ریتوش اضافه", price: "۷۵ دلار / تصویر", desc: "فراتر از تعداد توافق‌شده." },
  { code: "+D", name: "آرشیو فیلم", price: "۲۲۰ دلار", desc: "تبدیل نگاتیوها به دیجیتال و نگهداری آن‌ها." },
];

export const PROCESS = [
  {
    n: "۰۱",
    title: "برای ما بنویسید",
    desc: "بگویید کی هستید، پرتره برای چیست و چه ارجاع‌هایی را دوست دارید یا نمی‌پسندید.",
  },
  {
    n: "۰۲",
    title: "تماسِ پیش‌نور",
    desc: "گفت‌وگویی ویدیویی سی‌دقیقه‌ای برای هم‌راستایی در حال‌وهوا، پوشاک، مو و شکلِ روز.",
  },
  {
    n: "۰۳",
    title: "جلسه",
    desc: "نیم‌روز یا تمام‌روز در استودیو. آرام و گرم؛ هرگز بیش از هشت نفر سرِ صحنه.",
  },
  {
    n: "۰۴",
    title: "ویرایش",
    desc: "پروف‌های دست‌چین‌شده در ۲۴ ساعت. فایل‌های نهاییِ ریتوش‌شده تا هفت روز. بدون فیلتر.",
  },
];

export const STATS = [
  { value: "۸ سال", label: "پشت دوربین" },
  { value: "۱٬۴۰۰+", label: "پرترهٔ ثبت‌شده" },
  { value: "۴۲", label: "گزارش مجله" },
  { value: "۲۲۰ م²", label: "استودیوی بروکلین" },
];

export type FooterLink = { label: string; href?: string; ltr?: boolean };
export type FooterColumn = { title: string; links: FooterLink[] };

export const FOOTER_LINKS: FooterColumn[] = [
  {
    title: "کار",
    links: [
      { label: "نمونه‌کارها", href: "#/portfolio" },
      { label: "جلسه‌ها", href: "#features" },
      { label: "نرخ‌نامه", href: "#pricing" },
      { label: "فضای استودیو", href: "#/portfolio" },
      { label: "مطبوعات", href: "#/portfolio" },
    ],
  },
  {
    title: "استودیو",
    links: [
      { label: "درباره", href: "#about" },
      { label: "مارن اوکادا", href: "#about" },
      { label: "ژورنال", href: "#features" },
      { label: "فرایند", href: "#about" },
      { label: "تماس", href: "#contact" },
    ],
  },
  {
    title: "دیدار",
    links: [
      { label: "بروکلین، نیویورک" },
      { label: "فقط با وقت قبلی" },
      { label: "چهارشنبه تا پنجشنبه" },
      { label: STUDIO.phoneFa, ltr: true, href: "tel:+13475550142" },
      { label: STUDIO.email, ltr: true, href: "mailto:studio@noir.work" },
    ],
  },
];

export const price = (n: number) => fa(n.toLocaleString("en-US").replace(/,/g, "٬"));
